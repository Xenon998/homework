homework = '12'
hours = '1.5'
course = 'Python'
average_time = float(hours) / int(homework)
print(course, ', всего задач:', homework, ', затрачено часов:', hours, ', среднее время выполнения:', average_time)