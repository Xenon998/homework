name = "Kcения"
print("Имя:", name)
age = 21
print('Возраст:', age)
age += 1
print('Новый возраст:', age)
is_student ='True'
print('is_student:', is_student)