example = 'Программирование'
print(example[0])
print(example[-1])
print(example[7:16])
print(example[::-1])
print(example[1::2])